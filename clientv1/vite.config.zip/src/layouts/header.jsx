import React, { useEffect, useState } from "react";
import { Navbar, Nav, Dropdown, Image, Button } from "react-bootstrap";
import { useNavigate } from "react-router-dom";
import { Logout } from "../services/api";

const Header = () => {
  const navigate = useNavigate();

  const [userName, setUserName] = useState("Admin");
  const [userAvatar, setUserAvatar] = useState(
    "/assets/images/users/avatar-2.jpg"
  );

  useEffect(() => {
    const storedUser = localStorage.getItem("AvdUser");
    const storedAvatar = localStorage.getItem("AvdPicture");

    if (storedUser) setUserName(storedUser);
    if (storedAvatar) setUserAvatar(storedAvatar);
  }, []);

  const handleLogout = async () => {
    try {
      await Logout();
    } finally {
      localStorage.clear();
      navigate("/login", { replace: true });
    }
  };

  return (
    <>
      {/* 🔥 DARK HEADER STYLES */}
      <style>
        {`
          .app-header {
            background-color: #334155;
            border-bottom: 1px solid #334155;
          }

          .header-user-toggle {
            background: transparent !important;
            color: #e5e7eb !important;
          }

          .header-dropdown {
            background-color: #334155;
            border: 1px solid #334155;
          }

          .header-dropdown .dropdown-item,
          .header-dropdown .dropdown-item-text {
            color: #e5e7eb;
          }

          .header-dropdown .dropdown-item:hover {
            background-color: #1e293b;
          }
        `}
      </style>

      <Navbar expand="lg" className="app-header px-3" style={{ height: "70px" }}>
        {/* LEFT */}
        <Navbar.Brand href="/" className="d-flex align-items-center">
          <Image src="/assets/images/logo-dark.png" height={40} />
        </Navbar.Brand>

        {/* MOBILE MENU */}
        <Button
          variant="outline-light"
          className="ms-2 d-lg-none"
          onClick={() => console.log("Toggle sidebar")}
        >
          <i className="ri-menu-2-line"></i>
        </Button>

        <Navbar.Toggle aria-controls="header-navbar" />

        <Navbar.Collapse id="header-navbar">
          <Nav className="ms-auto align-items-center">
            <Dropdown align="end">
              <Dropdown.Toggle className="header-user-toggle d-flex align-items-center border-0">
                <Image
                  src={userAvatar}
                  roundedCircle
                  height={36}
                  width={36}
                  className="me-2"
                />
                <span className="d-none d-md-inline">{userName}</span>
              </Dropdown.Toggle>

              <Dropdown.Menu className="header-dropdown">
                <Dropdown.ItemText className="fw-semibold">
                  <i className="ri-user-line me-2"></i>
                  {userName}
                </Dropdown.ItemText>

                <Dropdown.Divider />

                <Dropdown.Item className="text-danger" onClick={handleLogout}>
                  <i className="ri-shut-down-line me-2"></i>
                  Log Out
                </Dropdown.Item>
              </Dropdown.Menu>
            </Dropdown>
          </Nav>
        </Navbar.Collapse>
      </Navbar>
    </>
  );
};

export default Header;
