import React from "react";
import Header from "./header";
import Sidebar from "./sidebar";
import Footer from "./footer";
import { Outlet } from "react-router-dom";

const Mainlayout = () => {
  return (
    <>
      {/* HEADER */}
      <Header />

      {/* BODY */}
      <div className="d-flex">
        {/* SIDEBAR */}
        <Sidebar />

        {/* PAGE CONTENT */}
        <main
          className="flex-grow-1 p-4 bg-light"
          style={{ minHeight: "calc(100vh - 70px)" }}
        >
          <Outlet />
          <Footer />
        </main>
      </div>
    </>
  );
};

export default Mainlayout;
