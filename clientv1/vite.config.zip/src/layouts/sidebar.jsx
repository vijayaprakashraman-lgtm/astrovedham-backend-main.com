import React from "react";
import { Nav } from "react-bootstrap";
import { NavLink } from "react-router-dom";
import {
  FaStar,
  FaHeart,
  FaCoins,
  FaUser,
  FaFileAlt,
  FaGem,
  FaHashtag,
  FaCalendarAlt,
  FaShoppingBag
} from "react-icons/fa";

const Sidebar = () => {
  const menus = [
    { to: "/generate-horoscope", label: "Generate Horoscope", icon: <FaStar /> },
    { to: "/order-list", label: "Order List", icon: <FaShoppingBag /> },
    // { to: "/super-horoscope", label: "Super Horoscope", icon: <FaStar /> },
    // { to: "/life-horoscope", label: "Life Horoscope", icon: <FaHeart /> },
    // { to: "/wealth-horoscope", label: "Wealth Horoscope", icon: <FaCoins /> },
    // { to: "/marriage-horoscope", label: "Marriage Horoscope", icon: <FaUser /> },
    // { to: "/single-page-horoscope", label: "Single-Page Horoscope", icon: <FaFileAlt /> },
    // { to: "/gemstone-horoscope", label: "Gemstone Horoscope", icon: <FaGem /> },
    // { to: "/numerology-horoscope", label: "Numerology Horoscope", icon: <FaHashtag /> },
    // { to: "/yearly-horoscope", label: "Yearly Horoscope", icon: <FaCalendarAlt /> },
  ];

  return (
    <aside
      className="astro-sidebar"
      style={{ width: "250px", minHeight: "calc(100vh - 70px)" }}
    >
      <div className="p-3">
        <div className="sidebar-title">Menus</div>

        <Nav className="flex-column gap-1">
          {menus.map((m) => (
            <NavLink
              key={m.to}
              to={m.to}
              className={({ isActive }) =>
                "astro-nav-link" + (isActive ? " active" : "")
              }
            >
              <span className="me-3 sidebar-icon">{m.icon}</span>
              {m.label}
            </NavLink>
          ))}
        </Nav>
      </div>
    </aside>
  );
};

export default Sidebar;
