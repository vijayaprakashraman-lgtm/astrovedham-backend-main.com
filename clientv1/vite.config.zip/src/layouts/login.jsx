import React from "react";
import { Container, Row, Col, Card, Button } from "react-bootstrap";
import { GoogleAuthProvider, signInWithPopup } from "firebase/auth";
import { auth } from "../services/firebase";
import { login } from "../services/api";
import { useNavigate } from "react-router-dom";

function Login() {
  const navigate = useNavigate();

  const handleGoogleLogin = async () => {
    try {
      const result = await signInWithPopup(auth, new GoogleAuthProvider());
      const idToken = await result.user.getIdToken();

      const response = await login({ idToken });
      if (response.status == 200) {
        localStorage.setItem("AvdToken", response.data.token);
        localStorage.setItem("AvdUser", response.data.name);
        localStorage.setItem("AvdPicture", response.data.picture);
        window.location.href = "/";
      } else {
        alert("Login failed. Please try again.");
      }
    } catch (error) {
      alert("Login failed. Please try again.");
      console.error("Login error:", error);
    }
  };

  return (
    <Container fluid className="p-0 min-vh-100">
      <Row className="g-0 min-vh-100">
        {/* LEFT LOGIN PANEL */}
        <Col lg={4} className="d-flex align-items-center">
          <Card className="border-0 w-100 p-4">
            <Card.Body>
              <div className="text-center mb-4">
                <img src="/assets/images/logo-d.png" height="100" alt="logo" />
                <h4 className="mt-4">Welcome!</h4>
                <p className="text-muted">Sign in to continue</p>
              </div>

              <div className="text-center">
                <Button
                  variant="light"
                  className="border-0"
                  onClick={handleGoogleLogin}
                >
                  <img
                    src="https://developers.google.com/identity/images/btn_google_signin_dark_normal_web.png"
                    alt="Google Sign-In"
                  />
                </Button>
              </div>

              <div className="mt-5 text-center text-muted">
                © {new Date().getFullYear()} Astrovedham. Crafted with{" "}
                <span className="text-danger">♥</span> by VILLZONE
              </div>
            </Card.Body>
          </Card>
        </Col>

        {/* RIGHT BACKGROUND PANEL */}
        <Col lg={8} className="d-none d-lg-block">
          <div className="h-100 authentication-bg"></div>
        </Col>
      </Row>
    </Container>
  );
}

export default Login;
