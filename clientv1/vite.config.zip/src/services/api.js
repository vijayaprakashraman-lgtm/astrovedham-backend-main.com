import { auth } from "./firebase";
import {
  createUserWithEmailAndPassword,
  sendEmailVerification,
  updateProfile,
  signOut
} from "firebase/auth";

const HOSTNAME = "http://localhost:5000";

/* -------------------- AUTH HELPERS -------------------- */

// ✅ Logout function (USED IN HEADER)
export const Logout = async () => {
  try {
    await signOut(auth);
  } catch (e) {
    console.error("Firebase logout error", e);
  }

  localStorage.removeItem("token");
  localStorage.removeItem("AvdToken");

  window.location.href = "/login";
};

// ✅ Fetch logged-in user data (USED IN MAINLAYOUT)
export const fetchUserData = async () => {
  const token = localStorage.getItem("token") || localStorage.getItem("AvdToken");
  if (!token) return null;

  const response = await fetch(`${HOSTNAME}/api/user_profile`, {
    method: "GET",
    headers: {
      "Content-Type": "application/json",
      "x-api-key": "helloworld",
      Authorization: `Bearer ${token}`,
    },
    credentials: "include",
  });

  if (!response.ok) {
    throw new Error("Failed to fetch user data");
  }

  return response.json();
};

/* -------------------- EXISTING FUNCTIONS -------------------- */

export async function login({ idToken }) {
  const response = await fetch(`${HOSTNAME}/api/google_login`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-api-key": "helloworld",
    },
    body: JSON.stringify({ idToken }),
    credentials: "include",
  });
  const data = await response.json();

  return {
    status: response.status,     // 👈 HTTP status code (200, 401, 500, etc.)
    ok: response.ok,             // 👈 true / false
    data,
  };

}

export async function place_order(data) {
  let token = localStorage.getItem("AvdToken");

  let response = await fetch(`${HOSTNAME}/api/place_order`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-api-key": "helloworld",
      Authorization: `Bearer ${token}`,
    },
    body: JSON.stringify(data),
    credentials: "include",
  });

  return response.json();
}

export async function getOrders(data) {
  let token = localStorage.getItem("AvdToken");

  let response = await fetch(`${HOSTNAME}/api/order_list`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-api-key": "helloworld",
      Authorization: `Bearer ${token}`,
    },
    body: JSON.stringify(data),
    credentials: "include",
  });
 
 const data1 = await response.json();

  return {
    status: response.status,     // 👈 HTTP status code (200, 401, 500, etc.)
    ok: response.ok,             // 👈 true / false
    data: data1,
  };
}