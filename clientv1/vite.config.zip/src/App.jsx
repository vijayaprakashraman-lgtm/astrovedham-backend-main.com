import React, { useEffect } from "react";
import {
  Route,
  createBrowserRouter,
  createRoutesFromElements,
  RouterProvider,
  Navigate,
} from "react-router-dom";

import { initializeApp } from "firebase/app";
import { getAnalytics } from "firebase/analytics";

// layouts
import Mainlayout from "./layouts/mainlayout";
import LoginLayout from "./layouts/login";

// pages
import Home from "./pages/home";
import GenerateHoroscope from "./pages/generate_horoscope";
import LifeHoroscope from "./pages/life_horoscope";
import SuperHoroscope from "./pages/super_horoscope";
import WealthHoroscope from "./pages/wealth_horoscope";
import MarriageHoroscope from "./pages/marriage_horoscope";
import SinglePageHoroscope from "./pages/single_page_horoscope";
import GemstoneHoroscope from "./pages/gemstone_horoscope";
import NumerologyHoroscope from "./pages/numerology_horoscope";
import YearlyHoroscope from "./pages/yearly_horoscope";
import OrderHistory from "./pages/order_history";
import OrderList from "./pages/order_list";

// 🔐 Firebase config
const firebaseConfig = {
  apiKey: "AIzaSyBtxi2e9cRhFZLQC1zc1LgW4_mPq9TXeDQ",
  authDomain: "astrovedham-66a0d.firebaseapp.com",
  projectId: "astrovedham-66a0d",
  storageBucket: "astrovedham-66a0d.firebasestorage.app",
  messagingSenderId: "902846948837",
  appId: "1:902846948837:web:d59c7c875048dc3ab0bb0c",
};

// 🔑 Auth check
const isLoggedIn = () => {
  return !!localStorage.getItem("AvdToken");
};

// 🔥 Init Firebase (Vite safe)
const app = initializeApp(firebaseConfig);
if (typeof window !== "undefined") {
  getAnalytics(app);
}

// 🛣️ Router
const router = createBrowserRouter(
  createRoutesFromElements(
    <>
      {/* LOGIN */}
      <Route
        path="/login"
        element={isLoggedIn() ? <Navigate to="/" replace /> : <LoginLayout />}
      />

      {/* MAIN / DASHBOARD */}
      <Route
        path="/"
        element={
          isLoggedIn() ? <Mainlayout /> : <Navigate to="/login" replace />
        }
      >
        <Route index element={<Home />} />
        <Route path="generate-horoscope" element={<GenerateHoroscope />} />
        <Route path="order-list" element={<OrderList />} />
        <Route path="life-horoscope" element={<LifeHoroscope />} />
        <Route path="super-horoscope" element={<SuperHoroscope />} />
        <Route path="wealth-horoscope" element={<WealthHoroscope />} />
        <Route path="marriage-horoscope" element={<MarriageHoroscope />} />
        <Route path="single-page-horoscope" element={<SinglePageHoroscope />} />
        <Route path="gemstone-horoscope" element={<GemstoneHoroscope />} />
        <Route path="numerology-horoscope" element={<NumerologyHoroscope />} />
        <Route path="yearly-horoscope" element={<YearlyHoroscope />} />
        <Route path="order-history" element={<OrderHistory />} />

        {/* fallback */}
        <Route path="*" element={<Home />} />
      </Route>
    </>
  )
);

export default function App() {
  useEffect(() => {
    // analytics init already done
  }, []);

  return <RouterProvider router={router} />;
}
