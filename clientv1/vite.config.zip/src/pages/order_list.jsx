import React, { useEffect, useState } from "react";
import { Row, Col, Card, Form, Button } from "react-bootstrap";
import { getOrders } from "../services/api";

const OrderList = () => {
  const [filters, setFilters] = useState({
    horoscope_type: "",
    search: "",
    status: "Pending",
  });

  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(false);

  /* ================= HELPERS ================= */

  const getGenderLabel = (g) => {
    if (g === "M") return "Male";
    if (g === "F") return "Female";
    return "-";
  };

  const getHoroscopeBadge = (type) => {
    const colorMap = {
      Single: "primary",
      Life: "success",
      Yearly: "info",
      Super: "warning",
      Numerology: "secondary",
      Gemstone: "danger",
      Marriage: "dark",
      Wealth: "success",
    };

    const labelMap = {
      Single: "Single Horoscope",
      Life: "Life Horoscope",
      Yearly: "Yearly Horoscope",
      Super: "Super Horoscope",
      Numerology: "Numerology",
      Gemstone: "Gemstone Horoscope",
      Marriage: "Marriage Horoscope",
      Wealth: "Wealth Horoscope",
    };

    return {
      label: labelMap[type] || type || "-",
      color: colorMap[type] || "secondary",
    };
  };

  /* ================= HANDLERS ================= */

  const handleChange = (name, value) => {
    setFilters((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const fetchOrders = async () => {
    try {
      setLoading(true);
      const res = await getOrders(filters);

      console.log("Order list response:", res);

      if (res.status === 200 ) {
        setOrders(res.data || []);
      } else {
        setOrders([]);
      }
    } catch (err) {
      console.error(err);
      setOrders([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchOrders();
  }, [filters.horoscope_type, filters.search]);

  /* ================= UI ================= */

  return (
    <Row>
      <Col md={12}>
        <Card>
          <Card.Body>
            <h4 className="card-title mb-3">Order List</h4>

            {/* FILTERS */}
            <Row className="mb-3">
              <Col md={4}>
                <Form.Label>Horoscope Type</Form.Label>
                <Form.Select
                  value={filters.horoscope_type}
                  onChange={(e) =>
                    handleChange("horoscope_type", e.target.value)
                  }
                >
                  <option value="">All</option>
                  <option value="Single">Single Horoscope</option>
                  <option value="Life">Life Horoscope</option>
                  <option value="Yearly">Yearly Horoscope</option>
                  <option value="Super">Super Horoscope</option>
                  <option value="Numerology">Numerology</option>
                  <option value="Gemstone">Gemstone Horoscope</option>
                  <option value="Marriage">Marriage Horoscope</option>
                  <option value="Wealth">Wealth Horoscope</option>
                </Form.Select>
              </Col>

              <Col md={8}>
                <Form.Label>Search</Form.Label>
                <Form.Control
                  type="text"
                  placeholder="Search Name, mobile, Fathername, mothername, email"
                  value={filters.search}
                  onChange={(e) =>
                    handleChange("search", e.target.value)
                  }
                />
              </Col>
            </Row>

            {/* RESULTS */}
            <Row>
              {loading ? (
                <Col md={12} className="text-center py-4">
                  Loading...
                </Col>
              ) : orders.length === 0 ? (
                <Col md={12} className="text-center py-4 text-muted">
                  No records found
                </Col>
              ) : (
                orders.map((row) => {
                  const badge = getHoroscopeBadge(row.horoscope_type);

                  return (
                    <Col md={12} key={row._id} className="mb-2">
                      <Card className="shadow-sm">
                        <Card.Body className="py-2">

                          {/* HEADER */}
                          <div className="d-flex justify-content-between align-items-center mb-1">
                            <div>
                              <strong className="text-primary">
                                {row.name}
                              </strong>
                              <span className="text-muted ms-2">
                                ({getGenderLabel(row.gender)})
                              </span>
                            </div>

                            <span className="badge bg-warning">
                              {row.status}
                            </span>
                          </div>

                          {/* TABLE */}
                          <table
                            className="table table-sm table-border mb-1"
                            style={{ fontSize: "15px" }}
                          >
                            <tbody>
                              <tr>
                                <th width="15%">Horoscope</th>
                                <td width="35%">
                                  <span
                                    className={`badge bg-${badge.color}`}
                                  >
                                    {badge.label}
                                  </span>
                                </td>

                                <th width="15%">Mobile</th>
                                <td width="35%">{row.mobile}</td>
                              </tr>

                              <tr>
                                <th>Email</th>
                                <td>{row.emailid || "-"}</td>

                                <th>Place</th>
                                <td>{row.place}</td>
                              </tr>

                              <tr>
                                <th>Father</th>
                                <td>{row.fathername}</td>

                                <th>Mother</th>
                                <td>{row.mothername}</td>
                              </tr>

                              <tr>
                                <th>DOB</th>
                                <td>
                                  {row.dob
                                    ? new Date(row.dob).toLocaleDateString()
                                    : "-"}
                                </td>

                                <th></th>
                                <td></td>
                              </tr>
                            </tbody>
                          </table>

                          {/* FOOTER */}
                          <div className="text-end mt-1">
                            <small className="text-muted me-3">
                              {new Date(row.created_at).toLocaleString()}
                            </small>
                            <Button
                              size="sm"
                              variant="outline-primary"
                            >
                              View
                            </Button>
                          </div>

                        </Card.Body>
                      </Card>
                    </Col>
                  );
                })
              )}
            </Row>

          </Card.Body>
        </Card>
      </Col>
    </Row>
  );
};

export default OrderList;
